class ProfileModel {
  final String id;
  final String? username;
  final String? fullName;
  final String? avatarUrl;
  final int currentLevel;
  final int xp;

  ProfileModel({
    required this.id,
    this.username,
    this.fullName,
    this.avatarUrl,
    required this.currentLevel,
    required this.xp,
  });

  factory ProfileModel.fromJson(Map<String, dynamic> json) {
    return ProfileModel(
      id: json['id'] as String,
      username: json['username'] as String?,
      fullName: json['full_name'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      currentLevel: json['current_level'] as int? ?? 1,
      xp: json['xp'] as int? ?? 0,
    );
  }
}

class LessonModel {
  final String id;
  final String title;
  final String description;
  final String content;
  final String category;
  final String difficultyLevel;
  final String format;
  final String minNetworkStrength;
  final bool safeForMotion;
  final String status;
  final String? uploadedBy;
  final String? rejectionReason;
  final DateTime? reviewedAt;
  final DateTime? createdAt;

  LessonModel({
    required this.id,
    required this.title,
    required this.description,
    required this.content,
    required this.category,
    required this.difficultyLevel,
    required this.format,
    required this.minNetworkStrength,
    required this.safeForMotion,
    this.status = 'approved',
    this.uploadedBy,
    this.rejectionReason,
    this.reviewedAt,
    this.createdAt,
  });

  factory LessonModel.fromJson(Map<String, dynamic> json) {
    return LessonModel(
      id: json['id']?.toString() ?? '',
      title: json['title'] as String? ?? 'Untitled',
      description: json['description'] as String? ?? '',
      content: json['content'] as String? ?? '',
      category: json['category'] as String? ?? 'General',
      difficultyLevel: json['difficulty_level']?.toString() ?? 'beginner',
      format: json['format'] as String? ?? 'text',
      minNetworkStrength: json['min_network_strength'] as String? ?? 'weak',
      safeForMotion: json['safe_for_motion'] as bool? ?? true,
      status: json['status']?.toString() ?? 'approved',
      uploadedBy: json['uploaded_by']?.toString(),
      rejectionReason: json['rejection_reason']?.toString(),
      reviewedAt: json['reviewed_at'] != null
          ? DateTime.tryParse(json['reviewed_at'].toString())
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'].toString())
          : null,
    );
  }

  Map<String, dynamic> toInsertJson() {
    return {
      'title': title,
      'description': description,
      'content': content,
      'category': category,
      'difficulty_level': difficultyLevel,
      'format': format,
      'min_network_strength': minNetworkStrength,
      'safe_for_motion': safeForMotion,
      'status': 'pending',
      'uploaded_by': uploadedBy,
    };
  }
}
