import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../models/lesson_model.dart';

class LessonRepository {
  final SupabaseClient _client;

  LessonRepository(this._client);

  // Uploads a local video file to Supabase Storage and returns a PUBLIC URL
  Future<String?> uploadVideoToStorage(
    String filePath,
    String fileName,
  ) async {
    try {
      await _client.storage
          .from('lesson-videos')
          .upload(fileName, File(filePath));

      final publicUrl = _client.storage
          .from('lesson-videos')
          .getPublicUrl(fileName);

      return publicUrl;
    } catch (e) {
      debugPrint('Video upload error: $e');
      return null;
    }
  }

  // Uploads a local thumbnail file to Supabase Storage and returns a PUBLIC URL
  Future<String?> uploadThumbnailToStorage(
    String filePath,
    String fileName,
  ) async {
    try {
      await _client.storage
          .from('lesson-thumbnails')
          .upload(fileName, File(filePath));

      final publicUrl = _client.storage
          .from('lesson-thumbnails')
          .getPublicUrl(fileName);

      return publicUrl;
    } catch (e) {
      debugPrint('Thumbnail upload error: $e');
      return null;
    }
  }

  // Creator submits lesson metadata + URLs (video thumbnail optional)
  Future<void> submitLesson({
    required LessonModel lesson,
    required String videoUrl,
    String? thumbnailUrl,
  }) async {
    final lessonId = lesson.id.isEmpty ? const Uuid().v4() : lesson.id;

    final payload = lesson.copyWith(
      id: lessonId,
      videoUrl: videoUrl,
      thumbnailUrl: thumbnailUrl ?? lesson.thumbnailUrl,
      status: 'pending',
      isPublished: false,
      createdAt: lesson.createdAt ?? DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await _client.from('lessons').upsert(payload.toJson());
  }

  Future<List<LessonModel>> getApprovedLessons() async {
    try {
      final lessons = await _fetchPublishedTable('lessons');
      return lessons;
    } catch (e) {
      debugPrint('getApprovedLessons error: $e');
      return [];
    }
  }

  Future<List<LessonModel>> getPendingLessons() async {
    try {
      final response = await _client
          .from('lessons')
          .select()
          .eq('status', 'pending')
          .order('created_at', ascending: false);
      return (response as List)
          .map((json) => LessonModel.fromJson(json as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('getPendingLessons error: $e');
      return [];
    }
  }

  Future<void> approveLesson({
    required String lessonId,
    required String adminId,
  }) async {
    await _client.from('lessons').update({
      'status': 'approved',
      'is_published': true,
      'approved_by': adminId,
      'approved_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', lessonId);
  }

  Future<void> rejectLesson({
    required String lessonId,
    required String adminId,
    required String notes,
  }) async {
    await _client.from('lessons').update({
      'status': 'rejected',
      'is_published': false,
      'admin_notes': notes,
      'approved_by': adminId,
      'approved_at': null,
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', lessonId);
  }

  Future<LessonModel?> getLessonById(String lessonId) async {
    try {
      final response = await _client
          .from('lessons')
          .select()
          .eq('id', lessonId)
          .maybeSingle();

      if (response == null) return null;
      return LessonModel.fromJson(response);
    } catch (e) {
      debugPrint('getLessonById error: $e');
      return null;
    }
  }

  Future<List<LessonModel>> _fetchPublishedTable(String table) async {
    final response = await _client
        .from(table)
        .select()
        .eq('status', 'approved')
        .eq('is_published', true)
        .order('created_at', ascending: false);

    return (response as List)
        .map((json) => LessonModel.fromJson(json as Map<String, dynamic>))
        .toList();
  }
}

